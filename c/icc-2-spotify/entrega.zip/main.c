#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"csv.h"


int main(int argc,char* argv[]){
    lista_t* l;
    l = initialize();//inicia-se uma lista
    char* entrada=read_line();//lendo a entrada
    FILE* fp=fopen(entrada,"r+");
    if (fp==NULL)
    {
        printf("ERRO!\n");
        return 0;
    }
    
    char line[BUFFER];
    int linha=0;
    while (fgets(line,sizeof(line),fp))//lendo até o final do documento linha por linha....
    {
        if (linha!=0)
        {
            char* token_t_id,*token_t_name,*token_al_id,*token_al_name,*token_art_id,*token_art_name,*token_t_date,*token_t_len,*token_t_pop;
            token_t_name = strtok(line,";");
            token_t_id = strtok(NULL,";");
            remove_space(token_t_id);//removemos o espaço do token afinal o .csv é formatado token_a; token_b; token_c\n
            token_al_name = strtok(NULL,";");
            remove_space(token_al_name);
            token_al_id = strtok(NULL,";");
            remove_space(token_al_id);
            token_art_name = strtok(NULL,";");
            remove_space(token_art_name);
            token_art_id = strtok(NULL,";");
            remove_space(token_art_id);
            token_t_date = strtok(NULL,";");
            remove_space(token_t_date);
            token_t_len = strtok(NULL,";");
            remove_space(token_t_len);
            token_t_pop = strtok(NULL,";");
            remove_space(token_t_pop);
            if(search_artist(l,token_art_name)==-1)
            {//se for um novo artista adicionar...
                add_art(l,token_art_id,token_art_name);
            }
            //adicionar a musica ao respectivo artista
            add_music(l,token_t_id,token_t_name,search_artist(l,token_art_name),token_t_date,token_t_len,token_t_pop);
        }
        
        linha++;
    }
    printar(l);//sortar a lista e printar os resultados!


    return 0;
}