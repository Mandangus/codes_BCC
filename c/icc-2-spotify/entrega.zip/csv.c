#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"csv.h"


struct track//tipo musica
{
    char *name,*id,*albname,*albid,*date;
    int length,pop,acou,dance,energy,inst,live,loud,speech,tempo,sign;
};
struct artist//tipo artista que contem uma lista de musicas
{
    char *name,*id;
    int song_num;
    double song_pop;
    track_t* songs;
};
struct lista//tipo lista que contem uma lista de artistas mais o numero de artistas e musicas totais
{
    int num_art,num_songs;
    artist_t* artistas;
};
void remove_space(char*string){//removendo o espaço da formatação do .csv
    int len=strlen(string);
    for (int i = 0; i < len-1; i++)
    {
        string[i]=string[i+1];
    }
    string[len-1]='\0';
}
lista_t* initialize(){
    lista_t* l;
    l=(lista_t*)malloc(sizeof(lista_t));
    l->num_art=0;
    l->artistas=(artist_t*)malloc((BUFFER)*sizeof(artist_t));
    l->artistas[0].songs=(track_t*)malloc(BUFFER*sizeof(track_t));
    l->num_songs=0;
    return l;
};
char* read_line(){
    char* aux=(char*)malloc(BUFFER*sizeof(char));
    char letra;
    int pos=0;
    do
    {
        letra=getchar();
        if (letra!='\n')
        {
            aux[pos]=letra;
        }
        pos++;
    } while (letra!='\n');
    aux[pos]='\0';
    return aux;
}
int search_artist(lista_t* l,char* nome){
    if (l->num_art==0)
    {
        return -1;
    }
    
    for (int i = 0; i < l->num_art; i++)
    {
        if (strcmp(l->artistas[i].name,nome)==0)
        {
            return i;
        }

    }
    return -1;

}//se existe o artista retorna o indice, caso contrário retorna -1
void add_music(lista_t* l,char*t_id,char*t_name,int indice,char*t_date,char*t_len,char*t_pop){//adicionar uma musica!
    int num=l->artistas[indice].song_num;
    l->artistas[indice].songs[num].name=strdup(t_name);
    l->artistas[indice].songs[num].id=strdup(t_id);
    l->artistas[indice].songs[num].pop=atoi(t_pop);
    l->artistas[indice].songs[num].length=atoi(t_len);
    l->artistas[indice].songs[num].date=strdup(t_date);
    l->artistas[indice].song_num++;
    l->num_songs++;
}
void add_art(lista_t* l,char*t_id,char*t_name){//adicionar um artista
    l->artistas[l->num_art].name=strdup(t_name);
    l->artistas[l->num_art].id=strdup(t_id);
    l->artistas[l->num_art].songs=(track_t*)malloc(BUFFER*sizeof(track_t));
    l->artistas[l->num_art].song_num=0;
    l->artistas[l->num_art].song_pop=0;
    l->num_art++;
}
void find_pop(lista_t* l){//media aritmetica da popularidade de cada musica de cada artista
    for (int i = 0; i < l->num_art; i++)
    {
        int sum=0;
        for (int j = 0; j < l->artistas[i].song_num; j++)
        {
            sum+=l->artistas[i].songs[j].pop;
        }
        l->artistas[i].song_pop=sum/l->artistas[i].song_num;
    }
    
}
void artcpy(artist_t*a,artist_t*aux){
    //src a para dest aux
    aux->id=strdup(a->id);
    aux->name=strdup(a->name);
    aux->songs=a->songs;
    aux->song_num=a->song_num;
    aux->song_pop=a->song_pop;
}
void trocar(artist_t*a,artist_t*b){
    artist_t* aux=(artist_t*)malloc(sizeof(artist_t));
    aux->songs=(track_t*)malloc(BUFFER*sizeof(track_t));
    artcpy(a,aux);//similar ao strcpy()!
    artcpy(b,a);
    artcpy(aux,b);
}
void sortar(lista_t* l){
    int flag=0;
    do
    {
        flag=0;
        for (int j = 0; j < l->num_art-1; j++)
        {
            if (l->artistas[j].song_pop<l->artistas[j+1].song_pop)
            {
                trocar(&l->artistas[j],&l->artistas[j+1]);
                flag=1;
            }
            
        } 
    } while (flag!=0);
    
}
void printar(lista_t* l){ 
    find_pop(l);//setamos a popularidade de cada artista
    sortar(l);//sort básico para arrumar por popularidade
    printf("O Dataset contem %d Artistas e %d Musicas\n",l->num_art,l->num_songs);
    printf("Os artistas mais populares sao:\n");
    for (int i = 0; i < l->num_art; i++)
    {
        printf("(%d) Artista: %s, Musicas: %d musicas, Popularidade: %.2lf, Link: https://open.spotify.com/artist/%s\n",i+1,l->artistas[i].name,l->artistas[i].song_num,l->artistas[i].song_pop,l->artistas[i].id);
    }
    
}
