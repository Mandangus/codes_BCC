typedef struct lista lis_t;
typedef struct no no_t;
lis_t* ini(int tam);
no_t* read_line();
void add_aluno(lis_t* l);
void printar(lis_t* l);
void remover(lis_t* l);
void search(lis_t* l);
