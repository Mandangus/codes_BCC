int** criar_matriz(int N,int T);
void printar(int** matriz,int N);
void busca_recursiva(int **matriz,int N,int x, int y,int T);
void colocar(int** matriz,int N,FILE *fp);